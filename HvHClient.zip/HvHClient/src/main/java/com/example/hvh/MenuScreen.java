package com.example.hvh;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class MenuScreen extends Screen {
    public MenuScreen() { super(Text.literal("HvH Menu")); }

    @Override
    protected void init() {
        int cx = width / 2, cy = height / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("AutoInventoryTotem"),
                b -> client.setScreen(new TotemScreen(this))).dimensions(cx - 100, cy - 25, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("SelfDestruct"),
                b -> client.setScreen(new SelfDestructScreen(this))).dimensions(cx - 100, cy + 5, 200, 20).build());
    }
}
