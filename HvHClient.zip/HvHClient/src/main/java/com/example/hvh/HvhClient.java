package com.example.hvh;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class HvhClient implements ClientModInitializer {
    private boolean nWasDown = false;

    @Override
    public void onInitializeClient() {
        Config.load();

        // AutoInventoryTotem çalışırken envanterle etkileşimi engelle
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof InventoryScreen)) return;
            ScreenMouseEvents.allowMouseClick(screen).register((s, x, y, b) -> !AutoInventoryTotem.busy(MinecraftClient.getInstance()));
            ScreenMouseEvents.allowMouseRelease(screen).register((s, x, y, b) -> !AutoInventoryTotem.busy(MinecraftClient.getInstance()));
            ScreenKeyboardEvents.allowKeyPress(screen).register((s, key, sc, mods) -> !AutoInventoryTotem.busy(MinecraftClient.getInstance()));
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (SelfDestruct.done) return;
            long window = client.getWindow().getHandle();
            boolean down = InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_N);
            if (down && !nWasDown && client.currentScreen == null && client.player != null) {
                client.setScreen(new MenuScreen());
            }
            nWasDown = down;
            AutoInventoryTotem.tick(client);
        });
    }
}
