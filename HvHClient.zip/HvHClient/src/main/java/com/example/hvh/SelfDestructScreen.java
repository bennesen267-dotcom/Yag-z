package com.example.hvh;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class SelfDestructScreen extends Screen {
    private final Screen parent;

    public SelfDestructScreen(Screen parent) {
        super(Text.literal("SelfDestruct"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2, cy = height / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("Evet"), b -> {
            SelfDestruct.run();
            client.setScreen(null);
        }).dimensions(cx - 105, cy + 10, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Hayır"),
                b -> client.setScreen(parent)).dimensions(cx + 5, cy + 10, 100, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Emin misin? Config ve mod dosyaları silinecek."), width / 2, height / 2 - 15, 0xFFFFFF);
        super.render(ctx, mx, my, delta);
    }
}
